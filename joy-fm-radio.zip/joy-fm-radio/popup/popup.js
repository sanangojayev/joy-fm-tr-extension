document.getElementById("play-button").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "play" });
  });
  
  document.getElementById("stop-button").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "stop" });
  });