let radioPlayer;

// Radyo çalma işlemini başlat
function playRadio() {
  if (!radioPlayer) {
    radioPlayer = new Audio("https://21633.live.streamtheworld.com/JOY_FM128AAC.aac");
    radioPlayer.play();
  }
}

// Radyo çalma işlemini durdur
function stopRadio() {
  if (radioPlayer) {
    radioPlayer.pause();
    radioPlayer = null;
  }
}

// Background script'ten gelen mesajları dinle
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "play") {
    playRadio();
  } else if (message.action === "stop") {
    stopRadio();
  }
});