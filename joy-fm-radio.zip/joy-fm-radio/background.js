// Offscreen document oluştur
async function setupOffscreenDocument() {
    const offscreenUrl = chrome.runtime.getURL("offscreen.html");
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [offscreenUrl],
    });
  
    if (existingContexts.length > 0) {
      return; // Offscreen document zaten açık
    }
  
    await chrome.offscreen.createDocument({
      url: offscreenUrl,
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Play JOY FM radio",
    });
  }
  
  // Popup'tan gelen mesajları dinle
  chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    await setupOffscreenDocument(); // Offscreen document'ı hazırla
  
    // Mesajı offscreen document'a ilet
    chrome.runtime.sendMessage(message);
  });